// API key
const API_KEY = "pk.eyJ1IjoibGFjYXJ1YW5hIiwiYSI6ImNrbmZkOHQxZjF6Y2EydnBqdTJyczhuZ2sifQ.MsrVUCCeCPYJsmMSNUTisg";
